function setup() {
  
  createCanvas(400, 400);
  
}

function draw() {
  
  rect(200,200,100,100);
  
  
  
}